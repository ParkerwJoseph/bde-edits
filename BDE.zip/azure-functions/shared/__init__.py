# Shared modules for Azure Functions

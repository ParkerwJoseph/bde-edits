export { default as PillarScoresDetail } from './PillarScoresDetail';
export { default as SinglePillarDetail } from './SinglePillarDetail';
export { default as RiskRadarDetail } from './RiskRadarDetail';
export { default as QuickStatsDetail } from './QuickStatsDetail';
export { default as CustomerHealthDetail } from './CustomerHealthDetail';
export { default as ProductHealthDetail } from './ProductHealthDetail';

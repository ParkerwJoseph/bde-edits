from api.user.routes import router

__all__ = ["router"]

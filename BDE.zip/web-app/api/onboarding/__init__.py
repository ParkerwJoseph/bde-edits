from api.onboarding.routes import router

__all__ = ["router"]

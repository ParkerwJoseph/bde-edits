from api.tenant.routes import router

__all__ = ["router"]

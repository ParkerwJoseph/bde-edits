from api.document.routes import router

__all__ = ["router"]

from api.prompt.routes import router

__all__ = ["router"]

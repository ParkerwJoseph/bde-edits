from api.auth.routes import router

__all__ = ["router"]

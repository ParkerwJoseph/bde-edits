"""QuickBooks connector module"""

from services.connectors.quickbooks.client import QuickBooksConnector

__all__ = ["QuickBooksConnector"]
